<?php $__env->startSection('content'); ?>
  <h1>About</h1>

  <h3><?php echo e($pembuat); ?></h3>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutt.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projek_mingguan_wafiq\resources\views/about.blade.php ENDPATH**/ ?>