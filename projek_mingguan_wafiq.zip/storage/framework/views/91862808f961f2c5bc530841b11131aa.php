<?php $__env->startSection('content'); ?>
  <h1 class="text-center">Data Mahasiswa</h1>
  <div class="row mt-4">
    <a href="/tambahmahasiswa" class="btn btn-success mb-2">Tambah Data +</a>
  </div>

  <?php if($message = Session::get('success')): ?>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
       Swal.fire({
        title: "Berhasil!",
        text: "<?php echo e($message); ?>",
        icon: 'success',
         confirmButtonText: 'OK'
      });
    })
  </script>
  <?php endif; ?>

  <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">NIM</th>
      <th scope="col">Prodi</th>
      <th scope="col">Email</th>
      <th scope="col">No. HP</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
  
    <?php $i = 1 ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo $i ?></th>
      <td><?php echo e($mahasiswa["name"]); ?></td>
      <td><?php echo e($mahasiswa["nim"]); ?></td>
      <td><?php echo e($mahasiswa["prodi"]); ?></td>
      <td><?php echo e($mahasiswa["email"]); ?></td>
      <td><?php echo e($mahasiswa["nphp"]); ?></td>
      <td>
        <a href="tampildata/<?php echo e($mahasiswa['id']); ?>" class="btn btn-primary">Edit</a>
        <!-- Changed href to javascript:void(0) to prevent navigation, added class 'delete', and data attributes -->
        <a href="javascript:void(0);" class="btn btn-danger delete" data-id="<?php echo e($mahasiswa['id']); ?>" data-name="<?php echo e($mahasiswa['name']); ?>">Hapus</a>
      </td> 
      <?php $i++ ?>
    </tr>
  </tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<script>
  $('.delete').click(function(){
    let id = $(this).attr('data-id');
    let nama = $(this).attr('data-name'); // Fixed variable name mapping to match usage
    
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: "btn btn-success",
        cancelButton: "btn btn-danger"
      },
      buttonsStyling: false
    });

    swalWithBootstrapButtons.fire({
      title: "Are you sure want to delete " + nama + "?", // Fixed variable usage from 'name' to 'nama'
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        window.location="/deletedata/"+id; // Fixed route from /delete/ to /deletedata/
        
        // This part might not be seen if the page redirects quickly, but keeping for structure
        swalWithBootstrapButtons.fire({
          title: "Deleted!",
          text: "Your file has been deleted.",
          icon: "success"
        });
      } else if (
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire({
          title: "Cancelled",
          text: "Your imaginary file is safe :)",
          icon: "error"
        });
      }
    });
  });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutt.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projek_mingguan_wafiq\resources\views/mahasiswa.blade.php ENDPATH**/ ?>