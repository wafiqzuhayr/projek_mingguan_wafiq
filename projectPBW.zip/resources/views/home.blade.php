@extends('layoutt.main')

@section('content')
  <h1>Hello</h1>


@endsection