

<?php $__env->startSection('content'); ?>
<article>
    <h1><?php echo e($new_berita["judul"]); ?></h1>
    <h3><?php echo e($new_berita["penulis"]); ?></h3>
    <p><?php echo e($new_berita["konten"]); ?></p>
</article>

<a href="/berita">Kembali</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutt.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectPBW\projectPBW\resources\views/singleberita.blade.php ENDPATH**/ ?>